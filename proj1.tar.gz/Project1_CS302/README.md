This project is a collaboration between Ria Patel and Skylar White. 

lib_info is a program that keeps track of information in a music library. 

