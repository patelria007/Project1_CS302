#  Project1_CS302

> This project is a collaboration between Ria Patel and Skylar White. 

> lib_info is a program that keeps track of information in a music library. 

## Compiling Instructions
- To compile this program, just run `make` in the command line. 
	- We created a makefile to do the compiling for us. 

- If you want to check if our program has memory leaks, run the following command on the example file: 
```shell
$ valgrind --leak-check=yes ./lib_info Music.txt
```


